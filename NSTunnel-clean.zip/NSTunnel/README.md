# NS TUNNEL

Android VPN app - UDP Custom tunnel.

## Build

GitHub Actions builds the debug APK automatically on push to main.
