package com.monvpn.custom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {
    private boolean isConnected = false;
    private VpnPagerAdapter pagerAdapter;
    private ViewPager2 viewPager;
    private StringBuilder fullLogs = new StringBuilder("[NS Tunnel] Mode UDP Custom initialise.");

    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (MyVpnService.BROADCAST_LOG.equals(intent.getAction())) {
                String msg = intent.getStringExtra("msg");
                appendLog(msg);
                if (msg != null && msg.contains("CONNECT") && pagerAdapter.homeFragment.tvStatus != null) {
                    pagerAdapter.homeFragment.tvStatus.clearAnimation();
                    View mainLayout = findViewById(R.id.mainLayout);
                    if (mainLayout != null) {
                        Snackbar snackbar = Snackbar.make(mainLayout, "NS TUNNEL CONNECTED", Snackbar.LENGTH_LONG);
                        snackbar.setBackgroundTint(android.graphics.Color.parseColor("#1E1E1E"));
                        snackbar.setTextColor(android.graphics.Color.parseColor("#00E676"));
                        snackbar.show();
                    }
                }
            } else if (MyVpnService.BROADCAST_TRAFFIC.equals(intent.getAction())) {
                long bytes = intent.getLongExtra("bytes", 0);
                if (pagerAdapter.homeFragment.tvTraffic != null) {
                    pagerAdapter.homeFragment.tvTraffic.setText("Data: " + (bytes / 1024) + " KB");
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager);
        pagerAdapter = new VpnPagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) ->
                tab.setText(position == 1 ? "LOGS" : "HOME")).attach();

        IntentFilter filter = new IntentFilter();
        filter.addAction(MyVpnService.BROADCAST_LOG);
        filter.addAction(MyVpnService.BROADCAST_TRAFFIC);
        registerReceiver(vpnReceiver, filter, Context.RECEIVER_EXPORTED);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_import) {
            pagerAdapter.homeFragment.triggerImport();
            return true;
        } else if (id == R.id.menu_export) {
            pagerAdapter.homeFragment.triggerExport();
            return true;
        } else if (id == R.id.menu_reset) {
            pagerAdapter.homeFragment.triggerReset();
            return true;
        } else if (id == R.id.menu_clear_logs) {
            clearGlobalLogs();
            pagerAdapter.logsFragment.updateLogs(fullLogs.toString());
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void switchToLogsTab() {
        if (viewPager != null) {
            viewPager.setCurrentItem(1, true);
        }
    }

    public void clearGlobalLogs() {
        fullLogs.setLength(0);
        fullLogs.append("[NS Tunnel] Console effacee.\n");
    }

    public void appendLog(String message) {
        fullLogs.append("\n").append(message);
        pagerAdapter.logsFragment.updateLogs(fullLogs.toString());
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void startVpn() {
        Intent intent = new Intent(this, MyVpnService.class);
        startService(intent);
        if (pagerAdapter.homeFragment.tvStatus != null) {
            pagerAdapter.homeFragment.tvStatus.setText("Statut: CONNECTE");
            pagerAdapter.homeFragment.tvStatus.setTextColor(android.graphics.Color.parseColor("#00E676"));
            pagerAdapter.homeFragment.btnConnect.setText("STOP TUNNEL");
            pagerAdapter.homeFragment.btnConnect.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(android.graphics.Color.RED));
            pagerAdapter.homeFragment.btnConnect.setTextColor(android.graphics.Color.WHITE);
        }
        isConnected = true;
    }

    public void stopVpn() {
        if (pagerAdapter.homeFragment.tvStatus != null) {
            pagerAdapter.homeFragment.tvStatus.clearAnimation();
            pagerAdapter.homeFragment.tvStatus.setText("Statut: Deconnecte");
            pagerAdapter.homeFragment.tvStatus.setTextColor(android.graphics.Color.WHITE);
            pagerAdapter.homeFragment.btnConnect.setText("START TUNNEL");
            pagerAdapter.homeFragment.btnConnect.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#00E676")));
            pagerAdapter.homeFragment.btnConnect.setTextColor(android.graphics.Color.parseColor("#121212"));
        }
        Intent intent = new Intent(this, MyVpnService.class);
        stopService(intent);
        isConnected = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(vpnReceiver);
    }
}
