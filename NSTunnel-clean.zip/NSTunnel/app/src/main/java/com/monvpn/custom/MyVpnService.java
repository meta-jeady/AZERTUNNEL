package com.monvpn.custom;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import androidx.core.app.NotificationCompat;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MyVpnService extends VpnService implements Runnable {
    private Thread mThread;
    private ParcelFileDescriptor mInterface;
    private DatagramChannel tunnel;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    private boolean isReconnecting = false;
    private boolean userDisconnected = false;

    public static final String BROADCAST_LOG = "com.nstunnel.LOG";
    public static final String BROADCAST_TRAFFIC = "com.nstunnel.TRAFFIC";
    private static final String CHANNEL_ID = "ns_tunnel_channel";
    private static final int NOTIFICATION_ID = 101;

    private void sendLog(String message) {
        SimpleDateFormat sdf = new SimpleDateFormat("[dd/MM/yyyy - HH:mm:ss]", Locale.getDefault());
        String timestamp = sdf.format(new Date());
        Intent intent = new Intent(BROADCAST_LOG);
        intent.putExtra("msg", timestamp + " " + message);
        sendBroadcast(intent);
    }

    private void showNotification(String statusText) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "NS Tunnel Service", NotificationManager.IMPORTANCE_LOW);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("NS TUNNEL")
                .setContentText(statusText)
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setContentIntent(pendingIntent);
        startForeground(NOTIFICATION_ID, builder.build());
    }

    private void startNetworkMonitor() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkRequest request = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();

        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                if (isReconnecting && !userDisconnected) {
                    sendLog("[Auto-Reconnect] Reseau detecte ! Reconnexion...");
                    showNotification("Reconnecting...");
                    triggerTunnelReconnection();
                }
            }

            @Override
            public void onLost(Network network) {
                if (!userDisconnected) {
                    isReconnecting = true;
                    sendLog("[Auto-Reconnect] Reseau perdu ! En attente...");
                    showNotification("Waiting for network...");
                }
            }
        };
        if (connectivityManager != null) {
            connectivityManager.registerNetworkCallback(request, networkCallback);
        }
    }

    private void triggerTunnelReconnection() {
        try {
            if (tunnel != null && tunnel.isOpen()) {
                tunnel.close();
            }
            tunnel = DatagramChannel.open();
            if (protect(tunnel.socket())) {
                tunnel.connect(new InetSocketAddress(TunnelConfig.serverIp, TunnelConfig.serverPort));
                sendLog("[Auto-Reconnect] Reconnexion reussie !");
                showNotification("Connected");
                isReconnecting = false;

                Intent intent = new Intent(BROADCAST_LOG);
                intent.putExtra("msg", "NS TUNNEL CONNECT");
                sendBroadcast(intent);
            }
        } catch (Exception e) {
            sendLog("[Auto-Reconnect] Echec : " + e.getMessage());
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                if (isReconnecting && !userDisconnected) {
                    triggerTunnelReconnection();
                }
            }, 5000);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        userDisconnected = false;
        isReconnecting = false;
        startNetworkMonitor();

        mThread = new Thread(this, "NS_Tunnel_Core");
        mThread.start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        userDisconnected = true;
        if (mThread != null) {
            mThread.interrupt();
        }
        sendLog("Tunnel stoppe.");

        if (connectivityManager != null && networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }
        stopForeground(true);
        try {
            if (mInterface != null) {
                mInterface.close();
            }
        } catch (IOException ignored) {
        }
        try {
            if (tunnel != null) {
                tunnel.close();
            }
        } catch (IOException ignored) {
        }
    }

    @Override
    public void run() {
        try {
            sendLog("Initialisation de l'interface NS TUNNEL...");
            Builder builder = new Builder();
            mInterface = builder
                    .addAddress("10.0.0.2", 24)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .setSession("NSTunnelCore")
                    .establish();
            sendLog("Interface TUN configuree.");

            sendLog("Connexion UDP vers " + TunnelConfig.serverIp + "...");
            tunnel = DatagramChannel.open();
            if (protect(tunnel.socket())) {
                tunnel.connect(new InetSocketAddress(TunnelConfig.serverIp, TunnelConfig.serverPort));
            }
            sendLog("NS TUNNEL CONNECT - Routage UDP actif.");
            showNotification("Connected");

            FileInputStream in = new FileInputStream(mInterface.getFileDescriptor());
            byte[] packet = new byte[32767];
            long totalBytes = 0;

            while (!Thread.interrupted()) {
                if (isReconnecting) {
                    Thread.sleep(500);
                    continue;
                }

                int length = in.read(packet);
                if (length > 0) {
                    if (tunnel != null && tunnel.isConnected()) {
                        tunnel.write(ByteBuffer.wrap(packet, 0, length));
                        totalBytes += length;

                        Intent trafficIntent = new Intent(BROADCAST_TRAFFIC);
                        trafficIntent.putExtra("bytes", totalBytes);
                        sendBroadcast(trafficIntent);
                    }
                }
                Thread.sleep(2);
            }
        } catch (Exception e) {
            if (!userDisconnected) {
                sendLog("Erreur : " + e.getMessage());
            }
        }
    }
}
