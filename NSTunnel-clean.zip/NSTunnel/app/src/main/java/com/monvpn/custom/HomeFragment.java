package com.monvpn.custom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONObject;

public class HomeFragment extends Fragment {
    public Button btnConnect;
    public CheckBox cbLockFile;
    public EditText etServer, etPort, etUser, etPassword;
    public TextView tvStatus, tvTraffic;
    public AlphaAnimation blinkAnimation;
    private MainActivity mainActivity;
    private SharedPreferences prefs;

    private static final int REQ_IMPORT = 21;
    private static final int REQ_EXPORT = 22;
    private static final int REQ_VPN = 15;
    private static final String PREFS_NAME = "NSTunnelPrefs";

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) context;
    }

    private String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("[dd/MM/yyyy - HH:mm:ss]", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void saveSettings(String server, int port, String user, String pass, boolean isLocked) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("server", server);
        editor.putInt("port", port);
        editor.putString("user", user);
        editor.putString("pass", pass);
        editor.putBoolean("lock", isLocked);
        editor.apply();
    }

    public void triggerImport() {
        vibratePhone(40);
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_IMPORT);
    }

    public void triggerExport() {
        vibratePhone(40);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, "config_fastssh.ns");
        startActivityForResult(intent, REQ_EXPORT);
    }

    public void triggerReset() {
        vibratePhone(40);
        prefs.edit().clear().apply();
        etServer.setEnabled(true);
        etPort.setEnabled(true);
        etUser.setEnabled(true);
        etPassword.setEnabled(true);
        etServer.setText("");
        etPort.setText("1194");
        etUser.setText("");
        etPassword.setText("");
        cbLockFile.setChecked(false);
        mainActivity.appendLog(getCurrentDateTime() + " [NS Config] Memoire effacee.");
        Toast.makeText(getContext(), "Configuration reinitialisee !", Toast.LENGTH_SHORT).show();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        btnConnect = view.findViewById(R.id.btnConnect);
        cbLockFile = view.findViewById(R.id.cbLockFile);
        etServer = view.findViewById(R.id.etServer);
        etPort = view.findViewById(R.id.etPort);
        etUser = view.findViewById(R.id.etUser);
        etPassword = view.findViewById(R.id.etPassword);
        tvStatus = view.findViewById(R.id.tvStatus);
        tvTraffic = view.findViewById(R.id.tvTraffic);

        etServer.setText(prefs.getString("server", "23.158.72.132"));
        etPort.setText(String.valueOf(prefs.getInt("port", 1194)));
        etUser.setText(prefs.getString("user", "fastssh.com-vps2"));
        etPassword.setText(prefs.getString("pass", "vps3"));
        boolean savedLock = prefs.getBoolean("lock", false);
        cbLockFile.setChecked(savedLock);

        if (savedLock) {
            etServer.setEnabled(false);
            etPort.setEnabled(false);
            etUser.setEnabled(false);
            etPassword.setEnabled(false);
            etPassword.setInputType(
                    android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }

        blinkAnimation = new AlphaAnimation(0.2f, 1.0f);
        blinkAnimation.setDuration(500);
        blinkAnimation.setRepeatMode(Animation.REVERSE);
        blinkAnimation.setRepeatCount(Animation.INFINITE);

        btnConnect.setOnClickListener(v -> {
            vibratePhone(50);
            if (!mainActivity.isConnected()) {
                String srv = etServer.getText().toString();
                int prt = Integer.parseInt(etPort.getText().toString());
                String usr = etUser.getText().toString();
                String pwd = etPassword.getText().toString();
                boolean lck = cbLockFile.isChecked();

                saveSettings(srv, prt, usr, pwd, lck);
                TunnelConfig.serverIp = srv;
                TunnelConfig.serverPort = prt;
                TunnelConfig.username = usr;
                TunnelConfig.password = pwd;

                tvStatus.setText("Statut: CONNEXION...");
                tvStatus.setTextColor(android.graphics.Color.parseColor("#FFB300"));
                tvStatus.startAnimation(blinkAnimation);
                mainActivity.appendLog(getCurrentDateTime() + " NS TUNNEL connecting...");
                mainActivity.switchToLogsTab();

                Intent intent = VpnService.prepare(getContext());
                if (intent != null) {
                    startActivityForResult(intent, REQ_VPN);
                } else {
                    mainActivity.startVpn();
                }
            } else {
                mainActivity.stopVpn();
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != android.app.Activity.RESULT_OK || data == null) {
            return;
        }
        Uri uri = data.getData();
        if (uri == null) {
            return;
        }
        try {
            if (requestCode == REQ_IMPORT) {
                InputStream is = requireContext().getContentResolver().openInputStream(uri);
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                is.close();

                String decodedStr = new String(Base64.decode(sb.toString(), Base64.DEFAULT));
                JSONObject json = new JSONObject(decodedStr);
                boolean isLocked = json.optBoolean("lock", false);
                String srv = json.getString("server");
                int prt = json.getInt("port");
                String usr = json.getString("user");
                String pwd = json.getString("pass");

                etServer.setText(srv);
                etPort.setText(String.valueOf(prt));
                etUser.setText(usr);
                etPassword.setText(pwd);
                cbLockFile.setChecked(isLocked);
                saveSettings(srv, prt, usr, pwd, isLocked);

                if (isLocked) {
                    etServer.setEnabled(false);
                    etPort.setEnabled(false);
                    etUser.setEnabled(false);
                    etPassword.setEnabled(false);
                    etPassword.setInputType(
                            android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
                } else {
                    etServer.setEnabled(true);
                    etPort.setEnabled(true);
                    etUser.setEnabled(true);
                    etPassword.setEnabled(true);
                }
                mainActivity.appendLog(getCurrentDateTime() + " [NS Config] Fichier charge.");
            } else if (requestCode == REQ_EXPORT) {
                JSONObject json = new JSONObject();
                json.put("server", etServer.getText().toString());
                json.put("port", Integer.parseInt(etPort.getText().toString()));
                json.put("user", etUser.getText().toString());
                json.put("pass", etPassword.getText().toString());
                json.put("lock", cbLockFile.isChecked());
                String encodedStr = Base64.encodeToString(json.toString().getBytes(), Base64.DEFAULT);
                OutputStream os = requireContext().getContentResolver().openOutputStream(uri);
                os.write(encodedStr.getBytes());
                os.close();
                mainActivity.appendLog(getCurrentDateTime() + " [NS Config] Profil exporte.");
            } else if (requestCode == REQ_VPN) {
                mainActivity.startVpn();
            }
        } catch (Exception e) {
            mainActivity.appendLog(getCurrentDateTime() + " [NS Config] Erreur");
        }
    }

    private void vibratePhone(int milliseconds) {
        Vibrator vibrator = (Vibrator) requireActivity().getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(milliseconds);
            }
        }
    }
}
