package com.monvpn.custom;

public class TunnelConfig {
    public static String serverIp = "";
    public static int serverPort = 1194;
    public static String username = "";
    public static String password = "";
}
