package com.monvpn.custom;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class VpnPagerAdapter extends FragmentStateAdapter {
    public HomeFragment homeFragment = new HomeFragment();
    public LogsFragment logsFragment = new LogsFragment();

    public VpnPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return position == 1 ? logsFragment : homeFragment;
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
