package com.monvpn.custom;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LogsFragment extends Fragment {
    private TextView tvLogsPage;
    private static String logHistory = "[NS Tunnel] En attente...";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_logs, container, false);
        tvLogsPage = view.findViewById(R.id.tvLogsPage);
        tvLogsPage.setText(logHistory);
        return view;
    }

    public void updateLogs(String text) {
        logHistory = text;
        if (tvLogsPage != null) {
            tvLogsPage.setText(logHistory);
        }
    }
}
